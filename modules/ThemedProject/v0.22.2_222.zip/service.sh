pm list packages | grep pro.themed.manager || pm install /data/adb/modules/ThemedProject/system/*/app/ThemedManager/*.apk
